#define __LIBRARY__
#include <unistd.h>

_syscall0(pid_t,setsid)
